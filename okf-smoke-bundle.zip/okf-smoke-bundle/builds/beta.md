---
type: Build
title: Beta Library
description: Smoke-test build that depends on Gamma; in production.
status: production
effort: S
impact: med
domain: Personal
timestamp: 2026-06-20T00:00:00Z
last_touched: 2026-06-18
tags: [smoke]
---

# What it is
A stable library Alpha depends on. Itself depends on Gamma.

# Next action
None — stable.

# Dependencies
* [Gamma Core](/builds/gamma.md) — Beta builds on Gamma.

# Notes
(none)
