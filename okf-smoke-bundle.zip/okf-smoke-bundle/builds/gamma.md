---
type: Build
title: Gamma Core
description: Smoke-test leaf build with no dependencies; in production.
status: production
effort: S
impact: high
domain: Personal
timestamp: 2026-06-20T00:00:00Z
last_touched: 2026-06-15
tags: [smoke]
---

# What it is
The leaf of the dependency chain. Beta depends on this; this depends on nothing.

# Next action
None — stable.

# Dependencies
(none)

# Notes
(none)
