---
type: Skill
title: Document Review
description: Use when reviewing a drafted document for clarity, structure, or policy conformance — not for first-draft generation. Produces tracked-change-style edits with rationale.
tags: [review, writing]
---

# When to use
A drafted doc needs a critical pass before it ships.

# Steps
1. Read for structure first, line edits second.
2. Flag each change with a one-line rationale.
3. Return edits as a diff-style list, not a rewritten doc.

# Inputs / Outputs
In: the draft. Out: ranked findings + proposed edits.
