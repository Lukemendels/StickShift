---
type: Foundation
title: Operating Profile
description: Who the operator is and the constraints the assistant works within. (Smoke-test placeholder.)
---

# Profile
Smoke-test foundation file. In the real bundle this holds the operator profile, the
constrained stack, and interaction preferences. Replace this when you seed for real.
